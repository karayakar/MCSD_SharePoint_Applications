﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.WebPartPages;

namespace CNRFC
{
    public class CalendarEditorPart : EditorPart
    {
        private const string CalendarEditorPartUserControlPath = @"~/_CONTROLTEMPLATES/CNRFC/CNRFC Calendar/CalendarEditorPartUserControl.ascx";
        const string UserControlID = "CalendarEditorPartUserControl";
        CalendarEditorPartUserControl EditorControl;
        CalendarWebPart CalendarWebPart;
        public List<Category> Categories { get; set; }
        private DropDownList ddlCalendarType;
        private TextBox txtCalW;
        private TextBox txtSite;
        private Button btnCurrent;
        private DropDownList ddlList;
        private DropDownList ddlCategoryFld;
        private Panel pnlCategories;
        private Table tblCategories;
        private Label lblError;
        private DropDownList ddlSource;

        protected override void CreateChildControls()
        {
            //base.CreateChildControls();
            ToolPane pane = this.Zone as ToolPane;
            if (pane != null)
            {
                pane.Cancel.CausesValidation = false;
                pane.Cancel.Click += new EventHandler(Cancel_Click);
            }
            this.EditorControl = this.Page.LoadControl(CalendarEditorPart.CalendarEditorPartUserControlPath) as CalendarEditorPartUserControl;
            this.EditorControl.ID = CalendarEditorPart.UserControlID;
            this.Controls.Add(EditorControl);
            ddlCalendarType = (DropDownList)EditorControl.FindControl("ddlCalendarType");
            txtCalW = (TextBox)EditorControl.FindControl("txtCalW");
            txtSite = (TextBox)EditorControl.FindControl("txtSite");
            btnCurrent = (Button)EditorControl.FindControl("btnCurrent");
            ddlList = (DropDownList)EditorControl.FindControl("ddlList");
            ddlCategoryFld = (DropDownList)EditorControl.FindControl("ddlCategoryFld");
            pnlCategories = (Panel)EditorControl.FindControl("pnlCategories");
            tblCategories = (Table)pnlCategories.FindControl("tblCategories");
            //cbGrid = (CheckBox)pnlCategories.FindControl("cbGrid");
            ddlSource = (DropDownList)EditorControl.FindControl("ddlSource");
            lblError = (Label)EditorControl.FindControl("lblError");
            this.ChromeType = PartChromeType.None;
            this.Width = System.Web.UI.WebControls.Unit.Pixel(275);
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            if (this.EditorControl.OriginalCategories != null)
            {
                this.Categories = this.EditorControl.OriginalCategories;
                this.ApplyChanges();
            }
        }

        private string JQueryScript()
        {
            try
            {
                System.Text.StringBuilder script = new System.Text.StringBuilder();
                script.Append("<script language='javascript' type='text/javascript'>" + Environment.NewLine);
                script.Append("$(document).ready(function() {" + Environment.NewLine);
                script.Append("$(\"a[id*='AppearanceCategory_IMAGEANCHOR']\").trigger('click');" + Environment.NewLine);
                script.Append("$(\"input[id*='_txtSite']\").removeClass();" + Environment.NewLine);
                script.Append("$(\"input[id*='_txtSite']\").css({'padding': '2', 'margin':'auto', 'border':'1px solid black', 'height':'16px', 'width':'224px'});" + Environment.NewLine);
                script.Append("$(\"input[id*='_btnCurrent']\").removeClass();" + Environment.NewLine);
                script.Append("$(\"input[id*='_btnCurrent']\").css({'padding': '2', 'margin':'auto', 'border':'1px solid red', 'height':'20px', 'width':'230px'});" + Environment.NewLine);
                script.Append("$('.ExpCol .ExpColHead').click(function() {var head = $(this);" + Environment.NewLine);
                script.Append("$(head).next(\".ms-propGridTable\").toggle();" + Environment.NewLine);
                script.Append("if($(head).parent().hasClass(\"expanded\")) {$(head).parent().removeClass(\"expanded\");}" + Environment.NewLine);
                script.Append("else {$(head).parent().addClass(\"expanded\");}return false;});" + Environment.NewLine);
                script.Append("});" + Environment.NewLine);
                script.Append("</script>" + Environment.NewLine);
                return script.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);
            writer.Write(JQueryScript());
        }

        public override bool ApplyChanges()
        {
            EnsureChildControls();
            CalendarWebPart = (CalendarWebPart)WebPartToEdit;
            if (CalendarWebPart == null) return false;
            try
            {
                if (!string.IsNullOrEmpty(ddlCalendarType.SelectedValue.ToString()))
                { CalendarWebPart.CalTypeId = ddlCalendarType.SelectedValue.ToString(); }
                else { CalendarWebPart.CalTypeId = "Month"; }
                if (!string.IsNullOrEmpty(txtCalW.Text))
                { CalendarWebPart.CalWidth = txtCalW.Text.ToString(); }
                else { CalendarWebPart.CalWidth = "1000"; }
                if (!string.IsNullOrEmpty(ddlSource.SelectedValue.ToString()))
                { CalendarWebPart.Source = ddlSource.SelectedValue.ToString(); }
                else { CalendarWebPart.Source = "jQuery"; }
                if (!string.IsNullOrEmpty(txtSite.Text))
                { CalendarWebPart.SiteUrl = txtSite.Text.ToString(); }
                else { CalendarWebPart.SiteUrl = string.Empty; }
                if (!string.IsNullOrEmpty(ddlList.SelectedItem.Text.ToString()))
                { CalendarWebPart.ListName = ddlList.SelectedItem.Text.ToString(); }
                else { CalendarWebPart.ListName = string.Empty; }
                if (!string.IsNullOrEmpty(ddlCategoryFld.SelectedItem.Text.ToString()))
                { CalendarWebPart.fldCategories = ddlCategoryFld.SelectedItem.Text.ToString(); }
                else { CalendarWebPart.fldCategories = string.Empty; }
                EditorControl.BuildCategories();
                if (Categories.Count > 0) { CalendarWebPart.Categories = Categories; }
                return true;
            }
            catch (Exception ex)
            {
                lblError.Text = String.Format("Error: {0} From: {1} StackTrace: {2}", ex.Message, ex.Source, ex.StackTrace);
                return false;
            }
        }

        public override void SyncChanges()
        {
            EnsureChildControls();
            CalendarWebPart = (CalendarWebPart)WebPartToEdit;
            if (CalendarWebPart == null) return;
            try
            {
                if (!string.IsNullOrEmpty(CalendarWebPart.CalTypeId)) { ddlCalendarType.SelectedValue = CalendarWebPart.CalTypeId; }
                if (!string.IsNullOrEmpty(CalendarWebPart.CalWidth)) { txtCalW.Text = CalendarWebPart.CalWidth; }
                if (!string.IsNullOrEmpty(CalendarWebPart.Source)) { ddlSource.SelectedValue = CalendarWebPart.Source; }
                if (!string.IsNullOrEmpty(CalendarWebPart.SiteUrl))
                {
                    txtSite.Text = CalendarWebPart.SiteUrl;
                    EditorControl.GetListsForSite(CalendarWebPart.SiteUrl);
                }
                if (!string.IsNullOrEmpty(CalendarWebPart.ListName))
                {
                    ddlList.SelectedValue = CalendarWebPart.ListName;
                    EditorControl.FillDropdowns();
                }
                if (CalendarWebPart.Categories != null && CalendarWebPart.Categories.Count > 0)
                {
                    Categories = CalendarWebPart.Categories;
                }
                if (!string.IsNullOrEmpty(CalendarWebPart.fldCategories))
                {
                    ddlCategoryFld.SelectedValue = ddlCategoryFld.Items.FindByText(CalendarWebPart.fldCategories).Value;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = String.Format("Error: {0} From: {1} StackTrace: {2}", ex.Message, ex.Source, ex.StackTrace);
            }
        }
    }
}
