﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Telerik.Web;
using Telerik.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;

namespace CNRFC
{
    public class CalendarWebPart : WebPart
    {
        private const string CalendarWebPartUserControlPath = @"~/_CONTROLTEMPLATES/CNRFC/CNRFC Calendar/CalendarWebPartUserControl.ascx";
        const string UserControlID = "CalendarWebPartUserControl";
        CalendarWebPartUserControl WebPartControl;

        private const string default_Text = "";
        public string CalTypeId;
        public string CalWidth;
        public string SiteUrl;
        public string ListName;
        public string fldCategories;
        private List<Category> lstCategories;
        private Panel pnlCalendar;
        private string strSource;
        public RadScheduler Scheduler;
        public RadPane RadButtonPane;
        public RadButton btnCNR;

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false), DefaultValue("Month")]
        public String strCalTypeId
        {
            get
            {
                if (String.IsNullOrEmpty(CalTypeId))
                {
                    CalTypeId = "Month";
                }
                return CalTypeId;
            }
            set { CalTypeId = value; }
        }

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false)]
        public String Source
        {
        get
            {
                if (String.IsNullOrEmpty(strSource))
                {
                    strSource = "jQuery";
                }
                return strSource;
            }
            set { strSource = value; }
        }

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false), DefaultValue("1000")]
        public String strCalWidth
        {
            get
            {
                if (String.IsNullOrEmpty(CalWidth))
                {
                    CalWidth = "1000";
                }
                return CalWidth;
            }
            set { if (value.Length <= 0) { CalWidth = "1000"; } else { CalWidth = value; } }
        }

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false)]
        public List<Category> Categories
        {
            get
            {
                if (lstCategories == null)
                {
                    lstCategories = new List<Category>();
                }
                return lstCategories;
            }
            set
            {
                lstCategories = value;
            }
        }

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false), DefaultValue(default_Text)]
        public String strSite
        {
            get { return SiteUrl; }
            set { SiteUrl = value; }
        }

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false), DefaultValue(default_Text)]
        public String strList
        {
            get { return ListName; }
            set { ListName = value; }
        }

        [Personalizable(PersonalizationScope.Shared), WebBrowsable(false), DefaultValue(default_Text)]
        public String strCategoriesFld
        {
            get { return fldCategories; }
            set { fldCategories = value; }
        }

        public bool isListUsed()
        {
            if (string.IsNullOrEmpty(ListName) | string.IsNullOrEmpty(SiteUrl))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static string StripTags(string html)
        {
            char[] ary = new char[html.Length];
            int aryidx = 0;
            bool inside = false;

            for (int i = 0; i < html.Length; i++)
            {
                char lt = html[i];
                if (lt == '<')
                {
                    inside = true;
                    continue;
                }
                if (lt == '>')
                {
                    inside = false;
                    continue;
                }
                if (!inside)
                {
                    ary[aryidx] = lt;
                    aryidx++;
                }
            }
            return new string(ary, 0, aryidx);
        }

        private string CalScript()
        {
            try
            {
                System.Text.StringBuilder script = new System.Text.StringBuilder();
                // Ensure that required values have some values.
                if (CalWidth == null || CalWidth == String.Empty) { CalWidth = "1000"; }
                if (CalTypeId == null || CalTypeId == String.Empty) { CalTypeId = "Month"; }
                if (Categories != null)
                {
                    script.Append("<style type='text/css'>" + Environment.NewLine);
                    for (var i = 0; i <= Categories.Count - 1; i++)
                    {
                        script.Append(String.Format(".{0} ", Categories[i].Title.ToString()));
                        script.Append("{ ");
                        script.Append(String.Format("background: {0}; color: {1};", Categories[i].Background.ToString(), Categories[i].Color.ToString()));
                        script.Append("} " + Environment.NewLine);
                    }
                    script.Append("</style>");
                }
                script.Append("<div id='CNRFC_Calendar'</div>" + Environment.NewLine);
                script.Append("<script type='text/javascript' src='/CNRFCAssets/js/jquery.min.js'></script>" + Environment.NewLine);
                script.Append("<script type='text/javascript' src='/CNRFCAssets/js/spectrum.js'></script>" + Environment.NewLine);
                script.Append("<script type='text/javascript' src='/CNRFCAssets/js/date.js'></script>" + Environment.NewLine);
                script.Append("<script type='text/javascript' src='/CNRFCAssets/js/jquery.SPServices-2014.01.min.js'></script>" + Environment.NewLine);
                script.Append("<script type='text/javascript' src='/CNRFCAssets/js/CNRFC.Calendar.js'></script>" + Environment.NewLine);
                if (!string.IsNullOrEmpty(strSource) && strSource.Equals("jQuery"))
                {
                    script.Append("<script language='javascript' type='text/javascript'>" + Environment.NewLine + Environment.NewLine);
                    script.Append("$(document).ready(function() {" + Environment.NewLine);
                    script.Append("$.fn.CNRFC_Calendar.Initialize({CalType:'" + CalTypeId + "'" + Environment.NewLine);
                    if (Categories != null)
                    {
                        script.Append(", categories:[");
                        for (var i = 0; i <= Categories.Count - 1; i++)
                        {
                            if (i == 0)
                            {
                                script.Append(String.Format("'{0}'", Categories[i].Title.ToString()));
                            }
                            else
                            {
                                script.Append(String.Format(", '{0}'", Categories[i].Title.ToString()));
                            }
                        }
                        script.Append("], " + Environment.NewLine);
                        script.Append("categorycss:[");
                        for (var i = 0; i <= Categories.Count - 1; i++)
                        {
                            if (i == 0)
                            {
                                script.Append(String.Format("'background: {0}; color: {1};'", Categories[i].Background.ToString(), Categories[i].Color.ToString()));
                            }
                            else
                            {
                                script.Append(String.Format(", 'background: {0}; color: {1};'", Categories[i].Background.ToString(), Categories[i].Color.ToString()));
                            }
                        }
                        script.Append("]" + Environment.NewLine);
                    }
                    script.Append("});" + Environment.NewLine);
                    script.Append("});" + Environment.NewLine);
                    script.Append("</script>" + Environment.NewLine);
                }
                return script.ToString();
            }
            catch (Exception ex)
            {
                return (String.Format("Error: {0} From: {1} StackTrace: {2}", ex.Message, ex.Source, ex.StackTrace));
            }
        }

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            
            System.Web.UI.HtmlControls.HtmlGenericControl CLink = new System.Web.UI.HtmlControls.HtmlGenericControl();
            CLink.Attributes.Add("type", "text/css");
            CLink.Attributes.Add("rel", "stylesheet");
            CLink.Attributes.Add("href", "/CNRFCAssets/css/CNRFCCalendarCSS.css");
            CLink.TagName = "link";
            CLink.RenderControl(writer);
            CLink = new System.Web.UI.HtmlControls.HtmlGenericControl();
            CLink.Attributes.Add("type", "text/css");
            CLink.Attributes.Add("rel", "stylesheet");
            CLink.Attributes.Add("href", "/CNRFCAssets/css/spectrum.css");
            CLink.TagName = "link";
            CLink.RenderControl(writer);
            writer.Write(CalScript());
            base.Render(writer);
        }

        protected override void CreateChildControls()
        {
            if (!string.IsNullOrEmpty(strSource) && strSource.Equals("Telerik"))
            {
                this.WebPartControl = this.Page.LoadControl(CalendarWebPart.CalendarWebPartUserControlPath) as CalendarWebPartUserControl;
                this.WebPartControl.ID = UserControlID;
                this.Controls.Add(WebPartControl);
                if (!string.IsNullOrEmpty(strSource) && strSource.Equals("Telerik"))
                {
                    pnlCalendar = (Panel)WebPartControl.FindControl("pnlCalendar");
                    pnlCalendar.Visible = true;
                    Scheduler = (RadScheduler)pnlCalendar.FindControl("Scheduler");
                    Scheduler.AppointmentDataBound += Scheduler_AppointmentDataBound;
                    RadButtonPane = FindControlRecursive(pnlCalendar, "RadButtonPane") as RadPane;
                    //Scheduler = new RadScheduler();
                    //Scheduler.ID = "Scheduler";
                    //Scheduler.Skin = "Sunset";

                    btnCNR = new RadButton();
                    btnCNR.ButtonType = RadButtonType.ToggleButton;
                    btnCNR.ToggleType = ButtonToggleType.CheckBox;
                    btnCNR.ButtonType = RadButtonType.LinkButton;
                    RadButtonToggleState ts = new RadButtonToggleState();
                    ts.Selected = true;
                    ts.CssClass = "rbToggleCheckboxChecked";
                    ts.Text = "CNR";
                    btnCNR.ToggleStates.Add(ts);
                    ts = new RadButtonToggleState();
                    ts.Selected = true;
                    ts.CssClass = "rbToggleCheckbox";
                    ts.Text = "CNR";
                    btnCNR.ToggleStates.Add(ts);
                    btnCNR.Click += btnCNR_Click;
                    RadButtonPane.Controls.Add(btnCNR);

                    Scheduler.TimelineView.UserSelectable = true;
                    Scheduler.Width = new Unit(1000, UnitType.Pixel);
                    Scheduler.Height = new Unit(650, UnitType.Pixel);
                    Scheduler.OverflowBehavior = OverflowBehavior.Scroll;
                    Scheduler.SelectedView = SchedulerViewType.TimelineView;
                    Scheduler.EnableViewState = false;
                    Scheduler.StartEditingInAdvancedForm = true;
                    Scheduler.StartInsertingInAdvancedForm = true;
                    Scheduler.AllowDelete = false;

                    DateTime baseDate = DateTime.Today;
                    DateTime thisMonthStart = baseDate.AddDays(1 - baseDate.Day);
                    var days = System.DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);

                    Scheduler.TimelineView.NumberOfSlots = days;
                    Scheduler.TimelineView.SlotDuration = new TimeSpan(24, 0, 0);
                    Scheduler.TimelineView.ColumnHeaderDateFormat = "dd";
                    Scheduler.TimelineView.ShowDateHeaders = true;
                    Scheduler.SelectedDate = thisMonthStart;

                    Scheduler.AppointmentStyleMode = AppointmentStyleMode.Auto;
                    //Scheduler.DataSource = GetCalendarItems();
                    Scheduler.AppointmentContextMenuSettings.EnableDefault = true;
                    Scheduler.TimeSlotContextMenuSettings.EnableDefault = true;
                    Scheduler.AllowDelete = true;
                    Scheduler.AllowEdit = true;
                    Scheduler.AllowInsert = true;
                    Scheduler.AppointmentInsert += Scheduler_AppointmentInsert;
                    Scheduler.AppointmentUpdate += Scheduler_AppointmentUpdate;
                    Scheduler.AppointmentDelete += Scheduler_AppointmentDelete;

                    //Scheduler.DataStartField = "StartDate";
                    //Scheduler.DataEndField = "EndDate";
                    //Scheduler.DataSubjectField = "Title";
                    //Scheduler.DataKeyField = "ItemID";
                    LoadSchedulerData();
                    //pnlCalendar.Controls.Add(Scheduler);
                }
            }
        }

        void Scheduler_AppointmentDataBound(object sender, SchedulerEventArgs e)
        {
            //throw new NotImplementedException();
            e.Appointment.Visible = false;
            FilterAppointment(e.Appointment, btnCNR, 1);
        }

        void btnCNR_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private static void FilterAppointment(Appointment appointment, ICheckBoxControl checkBox, int resourceId)
        {
            if (appointment.Resources.GetResource("CNRFResource", resourceId) != null && checkBox.Checked)
            {
                appointment.Visible = true;

            }
        }

        void btnCNR_ToggleStateChanged(object sender, ButtonToggleStateChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

        void Scheduler_AppointmentDelete(object sender, AppointmentDeleteEventArgs e)
        {
            SPWeb web = SPContext.Current.Web;
            var list = web.Lists[ListName];
            list.Items.DeleteItemById((int)e.Appointment.ID);
            LoadSchedulerData();
        }

        void Scheduler_AppointmentUpdate(object sender, AppointmentUpdateEventArgs e)
        {
            SPWeb web = SPContext.Current.Web;
            var list = web.Lists[ListName];
            var newEvent = list.Items.GetItemById((int)e.ModifiedAppointment.ID);
            newEvent["Title"] = e.ModifiedAppointment.Subject;
            newEvent["StartDate"] = e.ModifiedAppointment.Start;
            newEvent["EndDate"] = e.ModifiedAppointment.End;
            newEvent["RecurrenceRule"] = e.ModifiedAppointment.RecurrenceRule;
            newEvent["RecurrenceParentID"] = e.ModifiedAppointment.RecurrenceParentID;
            newEvent.Update();
            LoadSchedulerData();
        }

        void Scheduler_AppointmentInsert(object sender, AppointmentInsertEventArgs e)
        {
            SPWeb web = SPContext.Current.Web;
            var list = web.Lists[ListName];
            var newEvent = list.Items.Add();
            newEvent["Title"] = e.Appointment.Subject;
            newEvent["StartDate"] = e.Appointment.Start;
            newEvent["EndDate"] = e.Appointment.End;
            newEvent["RecurrenceRule"] = e.Appointment.RecurrenceRule;
            newEvent["RecurrenceParentID"] = e.Appointment.RecurrenceParentID;
            newEvent.Update();
            LoadSchedulerData();
        }

        private void LoadSchedulerData()
        {
            SPWeb web = SPContext.Current.Web;
            var list = web.Lists[ListName];
            Scheduler.DataSource = list.Items.GetDataTable();
            Scheduler.DataSubjectField = "Title";
            Scheduler.DataStartField = "StartDate";
            Scheduler.DataEndField = "EndDate";
            Scheduler.DataKeyField = "ID";
            Scheduler.DataRecurrenceField = "RecurrenceRule";
            Scheduler.DataRecurrenceParentKeyField = "RecurrenceParentID";
            Scheduler.DataBind();
        }

        public override EditorPartCollection CreateEditorParts()
        {
            CalendarEditorPart editorpart = new CalendarEditorPart();
            editorpart.ID = this.ID + "_editor";
            List<EditorPart> collection = new List<EditorPart>();
            collection.Add(editorpart);
            return new EditorPartCollection(base.CreateEditorParts(), collection);
        }

        public SPCalendarItemCollection GetCalendarItems()
        {
            SPWeb web = SPContext.Current.Web;
            if (!string.IsNullOrEmpty(ListName))
            {
                SPList selectedlist = web.Lists[ListName];
                SPListItemCollection calitems;
                SPCalendarItemCollection items = new SPCalendarItemCollection();
                DateTime baseDate = DateTime.Today;
                var thisMonthStart = baseDate.AddDays(1 - baseDate.Day);
                var thisMonthEnd = thisMonthStart.AddMonths(1).AddSeconds(-1);
                var isostart = SPUtility.CreateISO8601DateTimeFromSystemDateTime(thisMonthStart);
                var isoend = SPUtility.CreateISO8601DateTimeFromSystemDateTime(thisMonthEnd);

                StringBuilder cmlQry = new StringBuilder(String.Format("<Query><CalendarDate>{0}</CalendarDate>", isostart));

                cmlQry.Append("<Where><Or><Or><Or><Or><And><And><DateRangesOverlap><FieldRef Name='EventDate' /><FieldRef Name='EndDate' /><FieldRef Name='RecurrenceID' />");
                cmlQry.Append(String.Format("<Value Type='DateTime'>{0}</Value></DateRangesOverlap><Eq><FieldRef Name='fRecurrence' /><Value Type='Text'>1</Value></Eq></And>", isostart));
                cmlQry.Append(String.Format("<Leq><FieldRef Name='EventDate' /><Value Type='DateTime'>{0}</Value></Leq></And><And><And><Geq><FieldRef Name='EventDate' />", isoend));
                cmlQry.Append(String.Format("<Value Type='DateTime'>{0}</Value></Geq><Leq><FieldRef Name='EndDate' /><Value Type='DateTime'>{1}</Value></Leq></And>", isostart, isoend));
                cmlQry.Append("<Eq><FieldRef Name='fRecurrence' /><Value Type='Text'>0</Value></Eq></And></Or><And><And><And><Geq><FieldRef Name='EventDate' />");
                cmlQry.Append(String.Format("<Value Type='DateTime'>{0}</Value></Geq><Leq><FieldRef Name='EventDate' /><Value Type='DateTime'>{1}</Value></Leq></And><Gt>", isostart, isoend));
                cmlQry.Append(String.Format("<FieldRef Name='EndDate' /><Value Type='DateTime'>{0}</Value></Gt></And><Eq><FieldRef Name='fRecurrence' /><Value Type='Text'>0</Value></Eq></And></Or>", isoend));
                cmlQry.Append(String.Format("<And><And><And><Lt><FieldRef Name='EventDate' /><Value Type='DateTime'>{0}</Value></Lt><Leq><FieldRef Name='EndDate' /><Value Type='DateTime'>{1}</Value>", isostart, isoend));
                cmlQry.Append(String.Format("</Leq></And><Gt><FieldRef Name='EndDate' /><Value Type='DateTime'>{0}</Value></Gt></And>", isostart));
                cmlQry.Append("<Eq><FieldRef Name='fRecurrence' /><Value Type='Text'>0</Value></Eq></And></Or>");
                cmlQry.Append(String.Format("<And><And><Lt><FieldRef Name='EventDate' /><Value Type='DateTime'>{0}</Value></Lt><Gt><FieldRef Name='EndDate' /><Value Type='DateTime'>{1}</Value>", isostart, isoend));
                cmlQry.Append("</Gt></And><Eq><FieldRef Name='fRecurrence' /><Value Type='Text'>0</Value></Eq></And></Or></Where></Query>");

                SPQuery query = new SPQuery();
                query.Query = cmlQry.ToString();

                calitems = selectedlist.GetItems(query);

                foreach (SPListItem item in calitems)
                {
                    SPCalendarItem calItem = new SPCalendarItem();
                    calItem.ItemID = item["ID"].ToString();
                    calItem.Title = item["Title"].ToString();
                    calItem.CalendarType = Convert.ToInt32(SPCalendarType.Gregorian);
                    calItem.StartDate = (DateTime)item["Start"];
                    calItem.ItemID = item.ID.ToString();
                    if (item["End"] != null)
                    {
                        calItem.hasEndDate = true;
                        calItem.EndDate = (DateTime)item["End"];
                    }
                    else { calItem.hasEndDate = false; }

                    if (item["Description"] != null) calItem.Description = item["Description"].ToString();
                    if (item["Location"] != null) calItem.Location = item["Location"].ToString();
                    calItem.IsRecurrence = Convert.ToBoolean(item["Recurrence"]);
                    items.Add(calItem);
                }      
                return items;
            }
            else
            {
                SPCalendarItemCollection items = null;
                return items;
            }
        }

        public Control FindControlRecursive(Control root, string id)
        {
            if (root.ID == id) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, id);
                if (t != null) return t;
            }
            return null;
        }

        public override object WebBrowsableObject
        {
            get { return this; }
        }
    }
}
