﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CNRFC
{
    [Serializable]
    public class Category
    {
        public string Title { get; set; }
        public string Color { get; set; }
        public string Background { get; set; }
    }
}
