﻿using System;
using System.Web.UI;

namespace CNRFC
{
    public partial class CalendarWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}