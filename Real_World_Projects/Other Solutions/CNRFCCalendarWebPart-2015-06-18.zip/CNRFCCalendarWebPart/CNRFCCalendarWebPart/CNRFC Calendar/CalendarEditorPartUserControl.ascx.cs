﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;

namespace CNRFC
{
    public partial class CalendarEditorPartUserControl : UserControl
    {
        CalendarWebPart CalendarWebPart;
        private CalendarEditorPart parentEditorPart;
        public List<Category> Categories;
        public ArrayList choices;
        const string CategoriesViewStateId = "CategoriesViewState";

        protected void Page_Load(object sender, EventArgs e)
        {
            this.parentEditorPart = this.Parent as CalendarEditorPart;
            //this.parentEditorPart.SyncChanges();
            this.Categories = this.parentEditorPart.Categories;
            if (this.hiddenFieldDetectRequest.Value == "0")
            {
                this.hiddenFieldDetectRequest.Value = "1";
                this.SaveOriginalCategoriesToViewState();
                this.PopulateCategoriesTable();
            }
        }

        public void SaveOriginalCategoriesToViewState()
        {
            if (this.Categories != null)
            {
                this.ViewState[CategoriesViewStateId] = this.Categories;
            }
        }

        public List<Category> OriginalCategories
        {
            get
            {
                List<Category> retValue = null;
                retValue = this.ViewState[CategoriesViewStateId] as List<Category>;
                return retValue;
            }
        }

        public void PopulateCategoriesTable()
        {
            int i = 1;
            if (ddlCategoryFld.SelectedValue != "Select" && ddlList.SelectedValue != "Select")
            {
                try
                {
                    SPWeb web = SPContext.Current.Web;
                    SPList selectedlist = web.Lists[ddlList.SelectedValue];
                    choices = new ArrayList();
                    Category cat;
                    SPFieldChoice categories = (SPFieldChoice)selectedlist.Fields[ddlCategoryFld.SelectedValue];
                    foreach (String choice in categories.Choices)
                    {
                        if (Categories != null && Categories.Count > 0)
                        {
                            cat = (Category)Categories.Find(t => t.Title.Equals(choice));
                            if (cat == null)
                            {
                                cat = new Category();
                                cat.Title = choice;
                                Categories.Add(cat);
                            }
                        }
                        else
                        {
                            Categories = new List<Category>();
                            cat = new Category();
                            cat.Title = choice;
                            Categories.Add(cat);
                        }
                        String rowid = "ctblRow" + i.ToString();
                        String tbCatid = "tbCat" + i.ToString();
                        String tbTPickerid = "tbTPicker" + i.ToString();
                        String tbBPickerid = "tbBPicker" + i.ToString();
                        TextBox txtTColor;
                        TextBox txtBColor;
                        tblCategories.FindControl(rowid).Visible = true;
                        StringBuilder style = new StringBuilder();
                        TextBox txtCat = (TextBox)FindControlRecursive(tblCategories, tbCatid);
                        if (!String.IsNullOrEmpty(cat.Color))
                        {
                            style.Append(String.Format("color:{0};", cat.Color.ToString()));
                            txtTColor = (TextBox)FindControlRecursive(tblCategories, tbTPickerid);
                            txtTColor.Attributes.Add("Color", cat.Color);
                            txtTColor.Text = cat.Color;
                        }
                        else
                        {
                            // Did the Color textbox have a color applied?
                            txtTColor = (TextBox)FindControlRecursive(tblCategories, tbTPickerid);
                            if (!String.IsNullOrEmpty(txtTColor.Text))
                            {
                                style.Append(String.Format("color:{0};", txtTColor.Text));
                                txtTColor.Attributes.Add("Color", txtTColor.Text);
                            }
                            else
                            {
                                style.Append("color:#000000;");
                                txtTColor.Attributes.Add("Color", "#000000");
                            }
                        }
                        if (!String.IsNullOrEmpty(cat.Background))
                        {
                            style.Append(String.Format("background-color:{0};", cat.Background.ToString()));
                            txtBColor = (TextBox)FindControlRecursive(tblCategories, tbBPickerid);
                            txtBColor.Attributes.Add("Background", cat.Background);
                            txtBColor.Text = cat.Background;
                        }
                        else
                        {
                            // Did the Background textbox have a color applied?
                            txtBColor = (TextBox)FindControlRecursive(tblCategories, tbBPickerid);
                            if (!String.IsNullOrEmpty(txtBColor.Text))
                            {
                                style.Append(String.Format("background-color:{0};", txtBColor.Text));
                                txtBColor.Attributes.Add("Background", txtBColor.Text);
                            }
                            else
                            {
                                style.Append("background-color:#ffffff;");
                                txtBColor.Attributes.Add("Background", "#ffffff");
                            }
                        }
                        txtCat.Attributes.Add("style", style.ToString());
                        txtCat.Text = choice;
                        choices.Add(choice);
                        i += 1;
                    }
                }
                catch (Exception ex)
                {
                    lblError.Text = String.Format("{0}::{1}::{2}", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
                }
            }
        }

        public void btnUpdate_Click(object sender, EventArgs e)
        {
            BuildCategories();
            PopulateCategoriesTable();
        }

        public void BuildCategories()
        {
            SPWeb web = SPContext.Current.Web;
            SPList selectedlist = web.Lists[ddlList.SelectedValue];
            SPFieldChoice categories = (SPFieldChoice)selectedlist.Fields[ddlCategoryFld.SelectedValue];
            Category cat;
            Categories = new List<Category>();
            int i = 1;
            foreach (String choice in categories.Choices)
            {
                String tbCatid = "tbCat" + i.ToString();
                String tbTPickerid = "tbTPicker" + i.ToString();
                String tbBPickerid = "tbBPicker" + i.ToString();
                cat = new Category();
                cat.Title = choice;
                TextBox tb = (TextBox)FindControlRecursive(tblCategories, tbCatid);
                TextBox tbt = (TextBox)FindControlRecursive(tblCategories, tbTPickerid);
                TextBox tbb = (TextBox)FindControlRecursive(tblCategories, tbBPickerid);
                cat.Color = tbt.Text;   //tb.Attributes["Color"].ToString();
                cat.Background = tbb.Text;   //tb.Attributes["Background"].ToString();
                Categories.Add(cat);
                i += 1;
            }
            this.parentEditorPart.Categories = this.Categories;
            //this.parentEditorPart.ApplyChanges();
        }

        public void btnCurrent_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSite.Text))
            {
                SPWeb web = SPContext.Current.Web;
                txtSite.Text = web.Url.ToString();
                GetListsForSite(web.Url.ToString());
            }
            else
            {
                GetListsForSite(txtSite.Text.ToString());
            }
        }

        public void GetListsForSite(String SiteUrl)
        {
            ddlList.Items.Clear();
            using (SPSite Site = new SPSite(SiteUrl))
            {
                using (SPWeb Web = Site.OpenWeb())
                {
                    SPListCollection wlists = Web.Lists;
                    foreach (SPList x in wlists)
                    {
                        if (x.Hidden == false)
                        {
                            if (x.DoesUserHavePermissions(SPBasePermissions.ViewListItems))
                            {
                                ListItem nwItem = new ListItem();
                                nwItem.Text = x.Title;
                                nwItem.Value = x.Title;
                                ddlList.Items.Add(nwItem);
                            }
                        }
                    }
                }
            }
            ddlList.Items.Insert(0, new ListItem("Select", "Select"));
        }

        public void FillDropdowns()
        {
            if (ddlList.SelectedValue != "Select")
            {
                ddlCategoryFld.Items.Clear();

                fieldList(ddlCategoryFld);
            }
        }

        public void ddlList_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDropdowns();
        }

        public void ddlCategoryFld_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateCategoriesTable();
        }

        public DropDownList fieldList(DropDownList outgoingList)
        {
            SPWeb web = SPContext.Current.Web;
            SPList incominglist = web.Lists[ddlList.SelectedValue];
            outgoingList.Items.Clear();
            foreach (SPField field in incominglist.Fields)
            {
                if (field.Hidden != true)
                {
                    ListItem newItem = new ListItem();
                    newItem.Text = field.Title;
                    newItem.Value = field.InternalName;
                    outgoingList.Items.Add(newItem);
                }
            }
            outgoingList.Items.Insert(0, new ListItem("Select", ""));
            return outgoingList;
        }

        public Control FindControlRecursive(Control root, string id)
        {
            if (root.ID == id) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, id);
                if (t != null) return t;
            }
            return null;
        }
    }
}
